<?php
    //Redireciona para a listagem de alunos
    header("location: ./view/animais/listar.php");
    