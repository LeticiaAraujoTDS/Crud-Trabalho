<?php

require_once(__DIR__ . "/../controller/FuncionarioController.php");

$idHabitat = 0;
if (isset($_GET['id'])) {
    $idHabitat = $_GET['id'];
}

$funcCont = new FuncionarioController();
$funcionarios = $funcCont->listaPorHabitat($idHabitat);
$funcionarios_array = [];

foreach ($funcionarios as $f) {
    $texto = $f->getNome() . " (" . $f->getCargo() . ")";
    
    $funcionarios_array[] = [
        'id' => $f->getId(),
        'nome' => $texto
    ];
}

echo json_encode($funcionarios_array, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); // o JSON_UNESCAPED_UNICODE é prara aparecer a palavra com acentuação