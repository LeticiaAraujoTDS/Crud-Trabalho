<?php
require_once(__DIR__ . "/../controller/HabitatController.php");

$habitatCont = new HabitatController();

$habitats = $habitatCont->listar();

$habitats_array = [];

foreach ($habitats as $habitat) {
    $habitats_array[] = [
        'id' => $habitat->getId(),
        'nome' => $habitat->getNome()
    ];
}

echo json_encode($habitats_array, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
