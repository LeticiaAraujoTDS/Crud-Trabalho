<?php

require_once(__DIR__ . "/../../controller/FuncionarioController.php");
require_once(__DIR__ . "/../../controller/HabitatController.php");
include_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../../util/config.php");

?>

<span id="confUrlBase" data-url-base="<?= URL_BASE ?>"></span>

<h3 class="mt-3"><?= $animal && $animal->getId() > 0 ? 'ALTERAR' : 'INSERIR' ?> ANIMAL</h3>

<div class="row">

    <div class="col-6">
        <div class="form-card">
            <form method="POST" action="">

                <div class="form-group">
                    <label for="txtNome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="txtNome" placeholder="Digite o nome do animal" value="<?= $animal ? $animal->getNome() : '' ?>">
                </div>

                <div class="form-group">
                    <label for="selClassificacao" class="form-label">Classificação</label>
                    <select class="form-select" id="selClassificacao" name="selClassificacao">
                        <option value="">Selecione</option>
                        <option value="M" <?= $animal && $animal->getClassificacao() == 'M' ? 'selected' : '' ?>>Mamífero</option>
                        <option value="A" <?= $animal && $animal->getClassificacao() == 'A' ? 'selected' : '' ?>>Anfíbio</option>
                        <option value="R" <?= $animal && $animal->getClassificacao() == 'R' ? 'selected' : '' ?>>Réptil</option>
                        <option value="P" <?= $animal && $animal->getClassificacao() == 'P' ? 'selected' : '' ?>>Peixe</option>
                        <option value="V" <?= $animal && $animal->getClassificacao() == 'V' ? 'selected' : '' ?>>Ave</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="especie" class="form-label">Espécie</label>
                    <input type="text" class="form-control" id="especie" placeholder="Digite a espécie do animal" value="<?= $animal ? $animal->getEspecie() : '' ?>">
                </div>

                <div class="form-group">
                    <label for="selHabitat" class="form-label">Habitat</label>
                    <select class="form-select" id="selHabitat"
                        idSelecionado="<?= $animal && $animal->getHabitat() ? $animal->getHabitat()->getId() : 0 ?>">
                        <option value="0">--- Carregando habitats ---</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="selFuncionario" class="form-label">Funcionário</label>
                    <select class="form-select" id="selFuncionario" name="selFuncionario"
                        idSelecionado="<?= $animal && $animal->getFuncionario() ? $animal->getFuncionario()->getId() : 0 ?>">
                        <option value="0">--- Carregando funcionários ---</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="selPorte" class="form-label">Porte</label>
                    <select class="form-select" id="selPorte" name="selPorte">
                        <option value="">Selecione o porte</option>
                        <option value="P" <?= $animal && $animal->getPorte() == 'P' ? 'selected' : '' ?>>Pequeno</option>
                        <option value="M" <?= $animal && $animal->getPorte() == 'M' ? 'selected' : '' ?>>Médio</option>
                        <option value="G" <?= $animal && $animal->getPorte() == 'G' ? 'selected' : '' ?>>Grande</option>
                    </select>
                </div>

                <input type="hidden" name="id" value="<?= $animal ? $animal->getId() : 0 ?>">

                <div class="mt-3">
                    <button
                        type="button"
                        class="btn btn-primary w-100"
                        onclick="<?= $animal && $animal->getId() > 0 ? 'alterarAnimal()' : 'salvarAnimal()' ?>">
                        Enviar
                    </button>
                </div>

            </form>
        </div>
    </div>


    <div class="col-6 ">


        <div style="color: red; display: none;" class="alert alert-danger" id="msgErro" style="display: none;">
        </div>


    </div> <!-- col-6 -->

</div> <!-- row -->


<div class="mt-3">
    <a href="listar.php" class="btn btn-danger">Voltar</a>
</div>


<script src="js/animais.js"></script>

<?php

include_once(__DIR__ . "/../include/footer.php");
?>