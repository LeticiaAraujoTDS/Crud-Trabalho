const URL_BASE = document.getElementById('confUrlBase').dataset.urlBase;
const divErro = document.getElementById("msgErro");
const selHabitat = document.getElementById("selHabitat");
const selFuncionario = document.getElementById("selFuncionario");
const selectedFuncionarioId = selFuncionario ? selFuncionario.getAttribute("idSelecionado") : 0;
const selectedHabitatId = selHabitat ? selHabitat.getAttribute("idSelecionado") : 0;

function carregarSelectAjax() {


    selHabitat.innerHTML = `<option value="0">--- Carregando dados... ---</option>`;

    const url = URL_BASE + "/api/habitats.php";
    const xhttp = new XMLHttpRequest();

    xhttp.open('GET', url);

    xhttp.onload = function () {

        const dados = JSON.parse(xhttp.responseText);
        //carregpu as informações
        selHabitat.innerHTML = `<option value="0">Selecione</option>`;

        dados.forEach(h => {
            adicionarOption(h, selHabitat, selectedHabitatId);
        });

        if (selectedHabitatId > 0) {
            carregarFuncionarios();
        }

    }

    xhttp.send();
}

function adicionarOption(dados, selectElement, selectedId) {
    var option = document.createElement('option');
    option.value = dados.id;

    option.textContent = dados.nome;

    // se o id estiver selecionado, no carregamento da pagina ja vai estar selecionado
    if (selectedId === option.value) {
        //option.selected = true;
        option.setAttribute("selected", "true");
    }

    selectElement.appendChild(option);
}


function carregarFuncionarios() {
    selFuncionario.innerHTML = "";
    var url = URL_BASE + "/api/funcionario_por_habitat.php?id=" + selHabitat.value;
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", url);//o true já e padrrao

    //funcao de callback sera executada quando chegar a resposta da requisição
    xhttp.onload = function () {
        var json = xhttp.responseText;
        selFuncionario.innerHTML = `<option value="0">Selecione</option>`;


        //criar as options com base na resposta recebida em json
        var funcionarios = JSON.parse(json);
        funcionarios.forEach(f => {
            //console.log(d.id + " - " + d.nome);
            adicionarOption(f, selFuncionario, selectedFuncionarioId);
        });

    }

    xhttp.send();
}


function salvarAnimal() {

    const nome = document.getElementById("nome").value;
    const classificacao = document.getElementById("selClassificacao").value;
    const especie = document.getElementById("especie").value;
    const habitat = document.getElementById("selHabitat").value;
    const funcionario = document.getElementById("selFuncionario").value;
    const porte = document.getElementById("selPorte").value;

    const dados = new FormData();
    dados.append("nome", nome);
    dados.append("classificacao", classificacao);
    dados.append("especie", especie);
    dados.append("habitat", habitat);
    dados.append("funcionario", funcionario);
    dados.append("porte", porte);



    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", URL_BASE + "/api/animal_salvar.php");
    xhttp.onload = function () {
        const erros = xhttp.responseText;
        if (erros) {
            //exibir os erros
            divErro.innerHTML = erros;
            divErro.style.display = "block";
            //alert("Erros: \n" + erros);
        } else {
            //salvou o animal, redirecionar para o listar
            window.location = "listar.php";
        }
    };

    xhttp.send(dados);
}

function alterarAnimal() {

    const id = document.getElementsByName("id")[0].value;
    const nome = document.getElementById("nome").value;
    const classificacao = document.getElementById("selClassificacao").value;
    const especie = document.getElementById("especie").value;
    const habitat = document.getElementById("selHabitat").value;
    const funcionario = document.getElementById("selFuncionario").value;
    const porte = document.getElementById("selPorte").value;

    const dados = new FormData();
    dados.append("id", id);
    dados.append("nome", nome);
    dados.append("classificacao", classificacao);
    dados.append("especie", especie);
    dados.append("habitat", habitat);
    dados.append("funcionario", funcionario);
    dados.append("porte", porte);

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", URL_BASE + "/api/animal_alterar.php");
    xhttp.onload = function () {

        const erros = xhttp.responseText;

        if (erros) {
            divErro.innerHTML = erros;
            divErro.style.display = "block";
        } else {
            window.location = "listar.php";
        }
    };

    xhttp.send(dados);
}


window.onload = function () {
    carregarSelectAjax();   // carrega habitats ao entrar na página

    selHabitat.onchange = function () {
        carregarFuncionarios();   // carrega funcionários quando o habitat muda
    };
};

