<?php

require_once(__DIR__ . "/../dao/FuncionarioDAO.php");

class FuncionarioController{

    private FuncionarioDAO $FuncionarioDAO;


    public function __construct() {

        $this->FuncionarioDAO = new FuncionarioDAO();
    }

    public function listar(){
        $funcionarios = $this->FuncionarioDAO->listar();
        return $funcionarios;
    }
}