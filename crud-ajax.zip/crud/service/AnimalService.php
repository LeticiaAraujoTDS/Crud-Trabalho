<?php

require_once(__DIR__ . "/../model/Animal.php");

class AnimalService {

    public function validarAnimal(Animal $animal) {
        $erros = array();


        if ($animal->getNome() == null) {
            array_push($erros, "Informe o nome do animal!");
        } elseif (strlen($animal->getNome()) < 3 || strlen($animal->getNome()) > 50) {
            array_push($erros, "O nome deve ter entre 3 e 50 caracteres.");
        }
        if (!$animal->getClassificacao()) {
            array_push($erros, "Informe a classificação do animal!");
        }
        if ($animal->getEspecie() == null) {
            array_push($erros, "Informe se a espécie do animal!");
        }
        if (!$animal->getPorte()) {
            array_push($erros, "Informe se o porte do animal!");
        }
        if ($animal->getFuncionario()->getId() == null) {
            array_push($erros, "Informe o funcionário que cuida do animal!");
        }
        if ($animal->getHabitat()->getId() == null) {
            array_push($erros, "Informe o habitat do animal!");
        }
        return $erros;
    }
}