const URL_BASE = document.getElementById('confUrlBase').dataset.urlBase;
const divErro = document.getElementById("msgErro");

//para funcionar dinamicamente, passo esses parametros no carregamento da pagina, pois os selects sao estaticos
function carregarSelectAjax(selectId, caminho, selectedId = 0) {
    const selectElement = document.getElementById(selectId);
    if (!selectElement) return;

    selectElement.innerHTML = `<option value="0">--- Carregando dados... ---</option>`;

    const url = URL_BASE + caminho;
    const xhttp = new XMLHttpRequest();

    xhttp.open('GET', url);

    xhttp.onload = function () {

        const dados = JSON.parse(xhttp.responseText);
        //carregpu as informações
        selectElement.innerHTML = `<option value="0">Selecione</option>`;

        dados.forEach(d => {
            adicionarOption(d, selectElement, selectedId);
        })
    }

    xhttp.send();
}

function adicionarOption(dados, selectElement, selectedId) {
    var option = document.createElement('option');
    option.value = dados.id;

    option.textContent = dados.nome;

    // se o id estiver selecionado, no carregamento da pagina ja vai estar selecionado
    if (selectedId === dados.id) {
        option.selected = "selected";
    }

    selectElement.appendChild(option);
}

function salvarAnimal() {

    const nome = document.getElementById("nome").value;
    const classificacao = document.getElementById("selClassificacao").value;
    const especie = document.getElementById("especie").value;
    const habitat = document.getElementById("selHabitat").value;
    const funcionario = document.getElementById("selFuncionario").value;
    const porte = document.getElementById("selPorte").value;

    const dados = new FormData();
    dados.append("nome", nome);
    dados.append("classificacao", classificacao);
    dados.append("especie", especie);
    dados.append("habitat", habitat);
    dados.append("funcionario", funcionario);
    dados.append("porte", porte);



    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", URL_BASE + "/api/animal_salvar.php");
    xhttp.onload = function () {
        const erros = xhttp.responseText;
        if (erros) {
            //exibir os erros
            divErro.innerHTML = erros;
            divErro.style.display = "block";
        } else {
            //salvou o animal, redirecionar para o listar
            window.location = "listar.php";
        }
    };

    xhttp.send(dados);
}

document.addEventListener('DOMContentLoaded', function () {
    // Carregar Habitats
    const selHabitat = document.getElementById("selHabitat");
    //verifica se tem o select, pega o valor do select que ficou selecinado com o dataset, se nao tem retorna 0 que e o selecione
    const selectedHabitatId = selHabitat ? selHabitat.getAttribute("idSelecionado") : 0;
    carregarSelectAjax("selHabitat", URL_BASE + "/../api/habitats.php", selectedHabitatId);

    // Carregar Funcionários
    const selFuncionario = document.getElementById("selFuncionario");
    //verifica se tem o select, pega o valor do select que ficou selecinado com o dataset, se nao tem retorna 0 que e o selecione
    const selectedFuncionarioId = selFuncionario ? selFuncionario.getAttribute("idSelecionado") : 0;
    carregarSelectAjax("selFuncionario", URL_BASE + "/../api/funcionarios.php", selectedFuncionarioId);
});