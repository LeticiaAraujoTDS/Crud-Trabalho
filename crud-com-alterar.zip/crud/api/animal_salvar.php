<?php 
require_once(__DIR__ . "/../model/Animal.php");
require_once(__DIR__ . "/../model/Habitat.php"); 
require_once(__DIR__ . "/../model/Funcionario.php"); 
require_once(__DIR__ . "/../controller/AnimalController.php");

$nome = $_POST['nome'] ?? null;
$classificacao = $_POST['classificacao'] ?? null;
$especie = $_POST['especie'] ?? null;
$porte = $_POST['porte'] ?? null;

$idHabitat = is_numeric($_POST['habitat']) ? $_POST['habitat'] : null;
$idFuncionario = is_numeric($_POST['funcionario']) ? $_POST['funcionario'] : null;

$animal = new Animal();
$animal->setNome($nome);
$animal->setClassificacao($classificacao);
$animal->setEspecie($especie);
$animal->setPorte($porte);

$habitat = new Habitat();
$habitat->setId($idHabitat);
$animal->setHabitat($habitat);

$funcionario = new Funcionario();
$funcionario->setId($idFuncionario);
$animal->setFuncionario($funcionario);


$animalCont = new AnimalController();
$erros = $animalCont->inserir($animal);

$msgErro = "";
if($erros){
    $msgErro = implode("<br>", $erros);
}

echo $msgErro;