<?php

require_once(__DIR__ . "/../dao/HabitatDAO.php");

class HabitatController{

    private HabitatDAO $habitatDAO;

    public function __construct() {

        $this->habitatDAO = new HabitatDAO();
    }

    public function listar(){
        return $this->habitatDAO->listar();
    }
}