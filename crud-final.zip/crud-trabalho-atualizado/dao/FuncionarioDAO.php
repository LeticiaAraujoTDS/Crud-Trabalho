<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Funcionario.php");

class FuncionarioDAO
{

    private PDO $conexao;

    public function __construct()
    {

        $this->conexao = Connection::getConnection();
    }

    public function listar()
    {
        $sql = "SELECT * FROM funcionarios ORDER BY nome";
        $stm = $this->conexao->prepare($sql);
        $stm->execute();
        $resultado = $stm->fetchAll();
        return $this->map($resultado);
    }

    private function map(array $resultado)
    {
        $funcionarios = array();
        foreach ($resultado as $r) {
            $funcionario = new Funcionario();
            $funcionario->setId($r["id"]);
            $funcionario->setNome($r["nome"]);
            $funcionario->setCargo($r["cargo"]);

            array_push($funcionarios, $funcionario);
        }
        return $funcionarios;
    }
}
