<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Habitat.php");

class HabitatDAO
{

    private PDO $conexao;

    public function __construct()
    {

        $this->conexao = Connection::getConnection();
    }

    public function listar()
    {
        $sql = "SELECT * FROM habitats ORDER BY nome";
        $stm = $this->conexao->prepare($sql);
        $stm->execute();
        $resultado = $stm->fetchAll();
        return $this->map($resultado);
    }

    private function map(array $resultado)
    {
        $habitats = array();
        foreach ($resultado as $r) {
            $habitat = new Habitat();
            $habitat->setId($r["id"]);
            $habitat->setNome($r["nome"]);
            $habitat->setTipo($r["tipo"]);

            array_push($habitats, $habitat);
        }
        return $habitats;
    }
}
