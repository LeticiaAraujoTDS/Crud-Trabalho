<?php

require_once(__DIR__ . "/../../model/Animal.php");
require_once(__DIR__ . "/../../controller/AnimalController.php");

$msgErro = "";
$aluno = null;

if (isset($_POST['txtNome']) && isset($_POST['selClassificacao']) && isset($_POST['txtEspecie']) && isset($_POST['selHabitat']) && isset($_POST['selFuncionario']) && isset($_POST['selPorte'])) {

    //Já clicou no gravar
    $id = $_POST['id'];
    $nome = trim($_POST['txtNome']) ? trim($_POST['txtNome']) : NULL;
    $classificacao = $_POST['selClassificacao'] ? $_POST['selClassificacao'] : NULL;
    $especie = trim($_POST['txtEspecie']) ? trim($_POST['txtEspecie']) : NULL;
    $idHabitat = $_POST['selHabitat'] ? $_POST['selHabitat'] : NULL;
    $idFuncionario = $_POST['selFuncionario'] ? $_POST['selFuncionario'] : NULL;
    $porte = $_POST['selPorte'] ? $_POST['selPorte'] : NULL;

    //1- Capturar os dados do formulário
    $animal = new Animal();
    $animal->setNome($nome);
    $animal->setClassificacao($classificacao);
    $animal->setEspecie($especie);
    $animal->setId($id);
    $habitat = new Habitat();
    $habitat->setId($idHabitat);
    $animal->setHabitat($habitat);
    $funcionario = new Funcionario();
    $funcionario->setId($idFuncionario);
    $animal->setFuncionario($funcionario);
    $animal->setPorte($porte);
    //2-Chamar o controller para alterar
    $animalCont = new AnimalController();
    $erros = $animalCont->alterar($animal);

     if (!$erros) {
         //Redireciona para a listagem
        header("location: listar.php");
    } else{
        //Converte o array de erros para string
        $msgErro = implode("<br>", $erros);
        
    }
}
else {
    //Abriu a página para ver formulário 
    $id = 0;
    if (isset($_GET["id"])) {
        $id = $_GET["id"];
    }
    
    $animalCont = new AnimalController();
    $animal = $animalCont->buscarPorId($id);

    if (! $animal) {
        echo "AAAA<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }

}


include_once(__DIR__ . "/form.php");