<?php

require_once(__DIR__ . "/../../controller/FuncionarioController.php");
require_once(__DIR__ . "/../../controller/HabitatController.php");

$funcionarioCont = new FuncionarioController();
$funcionarios = $funcionarioCont->listar();

$habitatCont = new HabitatController();
$habitats = $habitatCont->listar();

include_once(__DIR__ . "/../include/header.php");

?>

<h3 class="mt-3"><?= $animal && $animal->getId() > 0 ? 'ALTERAR' : 'INSERIR' ?> ANIMAIS</h3>

<div class="row">

   <div class="col-6">
    <div class="form-card">
        <form method="POST" action="">

            <div class="form-group">
                <label for="txtNome" class="form-label">Nome</label>
                <input type="text" class="form-control" id="nome" name="txtNome" placeholder="Digite o nome do animal" value="<?= $animal ? $animal->getNome() : '' ?>">
            </div>

            <div class="form-group">
                <label for="selClassificacao" class="form-label">Classificação</label>
                <select class="form-select" id="selClassificacao" name="selClassificacao">
                    <option value="">Selecione</option>
                    <option value="M" <?= $animal && $animal->getClassificacao() == 'M' ? 'selected' : '' ?>>Mamífero</option>
                    <option value="A" <?= $animal && $animal->getClassificacao() == 'A' ? 'selected' : '' ?>>Anfíbio</option>
                    <option value="R" <?= $animal && $animal->getClassificacao() == 'R' ? 'selected' : '' ?>>Réptil</option>
                    <option value="P" <?= $animal && $animal->getClassificacao() == 'P' ? 'selected' : '' ?>>Peixe</option>
                    <option value="V" <?= $animal && $animal->getClassificacao() == 'V' ? 'selected' : '' ?>>Ave</option>
                </select>
            </div>

            <div class="form-group">
                <label for="txtEspecie" class="form-label">Espécie</label>
                <input type="text" class="form-control" id="especie" name="txtEspecie" placeholder="Digite a espécie do animal" value="<?= $animal ? $animal->getEspecie() : '' ?>">
            </div>

            <div class="form-group">
                <label for="selHabitat" class="form-label">Habitat</label>
                <select class="form-select" id="selHabitat" name="selHabitat">
                    <option value="">Selecione o habitat</option>
                    <?php foreach ($habitats as $h): ?>
                        <option value="<?= $h->getId() ?>" <?= ($animal && $animal->getHabitat()->getId() == $h->getId()) ? 'selected' : '' ?>>
                            <?= $h->getNome() . " (" . $h->getTipoTexto() . ")" ?>
                        </option> 
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="selFuncionario" class="form-label">Funcionário</label>
                <select class="form-select" id="selFuncionario" name="selFuncionario">
                    <option value="">Selecione o funcionário</option>
                    <?php foreach ($funcionarios as $f): ?>
                        <option value="<?= $f->getId() ?>" <?= ($animal && $animal->getFuncionario()->getId() == $f->getId()) ? 'selected' : '' ?>>
                            <?= $f->getNome() . " (" . $f->getCargo() . ")" ?>
                        </option> 
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="selPorte" class="form-label">Porte</label>
                <select class="form-select" id="selPorte" name="selPorte">
                    <option value="">Selecione o porte</option>
                    <option value="P" <?= $animal && $animal->getPorte() == 'P' ? 'selected' : '' ?>>Pequeno</option>
                    <option value="M" <?= $animal && $animal->getPorte() == 'M' ? 'selected' : '' ?>>Médio</option>
                    <option value="G" <?= $animal && $animal->getPorte() == 'G' ? 'selected' : '' ?>>Grande</option>
                </select>
            </div>

            <input type="hidden" name="id" value="<?= $animal ? $animal->getId() : 0 ?>">

            <div class="mt-3">
                <button type="submit" class="btn btn-primary w-100">Enviar</button>
            </div>

        </form>
    </div>
</div>


    <div class="col-6 ">

    <?php if ($msgErro): ?>

        <div style="color: red;" class="alert alert-danger"  > 
            <?= $msgErro ?>
        </div>

    <?php endif; ?>

    </div> <!-- col-6 -->

</div> <!-- row -->


<div class="mt-3">
    <a href="listar.php" class="btn btn-danger">Voltar</a>
</div>



<?php

include_once(__DIR__ . "/../include/footer.php");
?>