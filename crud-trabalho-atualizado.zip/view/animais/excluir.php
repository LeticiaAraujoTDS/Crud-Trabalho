<?php

require_once(__DIR__ . "/../../model/Animal.php");
require_once(__DIR__ . "/../../controller/AnimalController.php");

$msgErro = "";
$aluno = null;


//1 - receber o id do aluno
$id = 0;
if (isset($_GET['id'])) {
  $id = $_GET['id'];
}

// 2 - Chamar o controller para excluir o animal
$animalCont = new AnimalController();
$animal = $animalCont->buscarPorId($id);

if ($animal) {

  $erros = $animalCont->excluirPorId($animal->getId());

// 3 - Verficar se deu erro
 if (!$erros) {
         //Redireciona para a listagem
        //3.1 - Se não deu erro, redirecionar para a lista de animais
        header("location: listar.php");
        exit;
    } else{
        //Converte o array de erros para string
          //3.2 - Se deu erro, exibir o erro na própria página
        $msgErro = implode("<br>", $erros);
        echo $msgErro;
        
  } 

}
else {
  //4 - Se não encontrou o animal, exibir mensagem de erro
  echo "Animal não encontrado!";
  echo "<br><a href='listar.php'>Voltar</a>";
  exit;
}
