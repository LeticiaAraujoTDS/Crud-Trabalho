<?php

require_once(__DIR__ . "/../dao/AnimalDAO.php");
require_once(__DIR__ . "/../model/Animal.php");
require_once(__DIR__ . "../service/AnimalService.php");

class AnimalController
{

    private AnimalDAO $animalDAO;
    private AnimalService $animalService;

    public function __construct()
    {

        $this->animalDAO = new AnimalDAO();
        $this->animalService = new AnimalService();
    }

    public function listar()
    {
        return $this->animalDAO->listar();
    }

    public function buscarPorId($id)
    {
        return $this->animalDAO->buscarPorId($id);
    }

    public function excluirPorId(int $id)
    {
        $erro = $this->animalDAO->excluir($id);
        $erros = array();
        if ($erro) {
            array_push($erros, "Erro ao excluir o animal.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        }
        return $erro;
    }

    public function alterar(Animal $animal)
    {
        $erros = $this->animalService->validaranimal($animal);
        if (count($erros) > 0) {
            return $erros;
        }
        $erro = $this->animalDAO->alterar($animal);
        if ($erro != null) {
            array_push($erros, "Erro ao atualizar o animal.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        }
        return $erros;
    }

    public function inserir(Animal $animal)
    {
        $erros = $this->animalService->validaranimal($animal);
        if (count($erros) > 0) {
            return $erros;
        }
        $erro = $this->animalDAO->inserir($animal);
        if ($erro) {
            array_push($erros, "Erro ao salvar o animal.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        }
        return $erros;
    }
}
