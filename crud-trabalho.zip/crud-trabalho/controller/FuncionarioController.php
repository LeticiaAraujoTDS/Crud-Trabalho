<?php

require_once(__DIR__ . "../dao/FuncionarioDAO.php");

class FuncionarioController{

    private FuncionarioDAO $habitatDAO;

    public function __construct() {

        $this->FuncionarioDAO = new FuncionarioDAO();
    }

    public function listar(){
        return $this->FuncionarioDAO->listar();
    }
}