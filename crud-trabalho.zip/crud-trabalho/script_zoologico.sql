CREATE DATABASE db_zoologico;
USE db_zoologico;

/* 
TABELA habitats 
*/

CREATE TABLE habitats (
  id INT AUTO_INCREMENT NOT NULL,
  nome VARCHAR(70) NOT NULL,
  tipo VARCHAR(1) NOT NULL, /*T = Terrestre, A = Aquático, H = Híbrido, V = Viveiro */
  CONSTRAINT pk_habitats PRIMARY KEY (id)
);

/* INSERTs habitats */
INSERT INTO habitats (nome, tipo) VALUES ('Floresta Nativa', 'T');
INSERT INTO habitats (nome, tipo) VALUES ('Viveiro de Répteis', 'T');
INSERT INTO habitats (nome, tipo) VALUES ('Lagos / Viveiros Aquáticos', 'A');
INSERT INTO habitats (nome, tipo) VALUES ('Recinto de Grandes Felinos', 'T');
INSERT INTO habitats (nome, tipo) VALUES ('Viveiro de Aves e Harpias', 'V');
INSERT INTO habitats (nome, tipo) VALUES ('Margem Mata-Lago', 'H');

/* 
TABELA funcionarios 
*/
CREATE TABLE funcionarios (
  id INT AUTO_INCREMENT NOT NULL,
  nome VARCHAR(70) NOT NULL,
  cargo VARCHAR(50) NOT NULL,
  CONSTRAINT pk_funcionarios PRIMARY KEY (id)
);

/* INSERTs funcionarios */
INSERT INTO funcionarios (nome, cargo) VALUES ('Marina Silva', 'Veterinária Conservação');
INSERT INTO funcionarios (nome, cargo) VALUES ('Carlos Pereira', 'Tratador de Felinos');
INSERT INTO funcionarios (nome, cargo) VALUES ('Ana Beatriz Santos', 'Tratadora de Répteis');
INSERT INTO funcionarios (nome, cargo) VALUES ('Luiz Fernando', 'Ornitólogo / Cuidador de Aves');
INSERT INTO funcionarios (nome, cargo) VALUES ('Juliana Costa', 'Cuidadora de Mamíferos Aquáticos');

/*
TABELA animais
*/
CREATE TABLE animais (
  id INT AUTO_INCREMENT NOT NULL,
  nome VARCHAR(70) NOT NULL,
  classificacao VARCHAR(1) NOT NULL, /*M = Mamíferos, A = Anfíbios, R = Répteis, V = Aves, P = Peixes*/
  especie VARCHAR(100) NOT NULL,
  id_habitat INT NOT NULL,
  id_funcionario INT NOT NULL,
  porte VARCHAR(1) NOT NULL, /* G = Grande, M = Médio, P = Pequeno */
  CONSTRAINT pk_animais PRIMARY KEY (id)
);

ALTER TABLE animais 
  ADD CONSTRAINT fk_habitat FOREIGN KEY (id_habitat) REFERENCES habitats (id);

ALTER TABLE animais 
  ADD CONSTRAINT fk_funcionario FOREIGN KEY (id_funcionario) REFERENCES funcionarios (id);

/*
Dados para inserção
 INSERTs animais de exemplo 
INSERT INTO animais (nome, classificacao, especie, id_habitat, id_funcionario, porte) VALUES
('Juma', 'Mamíferos', 'Panthera onca', 4, 2, 'Grande'),         -- Onça-pintada
('Ariel', 'Mamíferos', 'Lontra longicaudis', 3, 5, 'Médio'),     -- Lontra
('Tangerina', 'Mamíferos', 'Chrysocyon brachyurus', 1, 1, 'Médio'), -- Lobo-guará
('Harpyia', 'Aves', 'Harpia harpyja', 5, 4, 'Grande'),           -- Harpia
('Jacaré do Pantanal', 'Répteis', 'Caiman latirostris', 2, 3, 'Grande');
*/
