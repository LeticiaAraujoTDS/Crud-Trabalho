<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "db_zoologico");
define("DB_USER", "root");
define("DB_PASSWORD", "leticia2007");//mudar a senha!!!

//Configuração do ambiente

// define("AMB_DEV", true);
define("AMB_DEV", false);