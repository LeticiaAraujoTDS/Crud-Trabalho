 <footer>
 </footer>

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

 </div>
 <!-- está fechando a div container -->
 </body>

 </html>